-- SQLite
.tables

SELECT * from users;
SELECT * FROM tarefas;







